MSREDepletionKyle773-15.out is the file that we are trying to replicate

MSREORIGEN.inpt utilizes the InterpLib.bof/MSREDepletionKyle773-15.f33 for the libraries
as well as uses the .f71 for initial isotopes